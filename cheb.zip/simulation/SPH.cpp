#include "SPH.h"
#include "2DMath.h"
#include <algorithm>
#include <array>
#include <boost/range/combine.hpp>
#include <iostream>
#include <numeric>
#include <chrono>
#include <sstream>

std::vector<int32_t> &getCell(scalar x, scalar y) {
  if (x != x)
    x = (scalar)0.0;
  if (y != y)
    y = (scalar)0.0;
  std::size_t xi = static_cast<std::size_t>(::floor(std::clamp(x, (scalar)0.0, domainWidth) / scale) );
  std::size_t yi = static_cast<std::size_t>(::floor(std::clamp(y, (scalar)0.0, domainHeight) / scale) );
  xi = std::clamp(xi, (std::size_t)0, cellsX - 1);
  yi = std::clamp(yi, (std::size_t)0, cellsY - 1);
  return cellArray[yi * (cellsX) + xi];
}

std::pair<int32_t, int32_t> getCellIdx(scalar x, scalar y) {
    if (x != x)
        x = (scalar)0.0;
    if (y != y)
        y = (scalar)0.0;
    std::size_t xi = static_cast<std::size_t>(::floor(std::clamp(x, (scalar)0.0, domainWidth) / scale));
    std::size_t yi = static_cast<std::size_t>(::floor(std::clamp(y, (scalar)0.0, domainHeight) / scale));
    xi = std::clamp(xi, (std::size_t)0, cellsX - 1);
    yi = std::clamp(yi, (std::size_t)0, cellsY - 1);
    return std::make_pair((int32_t)xi, (int32_t)yi);
}

std::vector<int32_t>& getCell(int32_t xi, int32_t yi) {
    return cellArray[yi * (cellsX)+xi];
}

void fillCells() {
  for (int32_t i = 0; i < particles.size(); ++i)
    getCell(particles[i].pos.x(), particles[i].pos.y()).push_back(i);
}

void neighborList() {
#pragma omp parallel for
  for (int32_t i = 0; i < particles.size(); ++i) {
    auto &p = particles[i];
    auto [ix, iy] = getCellIdx(p.pos.x(), p.pos.y());

    for (int32_t xi = -1; xi <= 1; ++xi) {
      for (int32_t yi = -1; yi <= 1; ++yi) {
        const auto &cell = getCell(ix + xi, iy + yi);
        for (auto j : cell) {
          auto &pj = particles[j];
          vec r = pj.pos - p.pos;
          if (r.squaredNorm() <= support * support)
            p.neighbors.push_back(j);
        }
      }
    }
  }
}

void density() {
#pragma omp parallel for
  for (int32_t i = 0; i < particles.size(); ++i) {
    auto &pi = particles[i];
    for (int32_t j : pi.neighbors) {
        auto& pj = particles[j];
        pi.rho += area * W(pi.pos, pj.pos);
    }
    //pi.rho = std::max(pi.rho, 0.5);
    boundaryFunc(pi.pos, [&pi, i](auto bpos, auto d, auto k, auto gk, auto triangle) {
		//std::cout << i << " - " << pi.pos.x() << " : " << pi.pos.y() << " -> " << bpos.x() << " : " << bpos.y() << ", " << d << ", " << k << ", " << gk.x() << " : " << gk.y() << std::endl;
		pi.rho += k; });
    
  }
}


void externalForces() {
  for (auto &p : particles)
    p.accel += gravity;
}

void XSPH() {
    static auto& viscosityConstant = ParameterManager::instance().get<scalar>("ptcl.viscosityConstant");
  std::vector<vec> tempV;
  for (int32_t i = 0; i < particles.size(); ++i) {
    auto &pi = particles[i];
    tempV.push_back(pi.vel);
    for (auto &j : pi.neighbors) {
      auto &pj = particles[j];
      tempV[i] += viscosityConstant * area / (pi.rho + pj.rho) * scalar(2.0) * W(pi.pos, pj.pos) * (pj.vel - pi.vel);
    }
  }
  for (int32_t i = 0; i < particles.size(); ++i)
    particles[i].vel = tempV[i];
}

void Integrate(void) {
  scalar vMax = 0.0;
  for (int32_t i = 0; i < particles.size(); ++i) {
	auto& p = particles[i];
	p.vel += dt * p.accel;
    p.pos += dt * p.vel;
    vMax = std::max(vMax, p.vel.norm());
    //if (p.pos.x() - domainEpsilon < 0.0f) {
    //  p.vel(0) *= dampingFactor;
    //  p.pos.x() = domainEpsilon;
    //}
    //if (p.pos.x() + domainEpsilon > domainWidth) {
    //  p.vel(0) *= dampingFactor;
    //  p.pos.x() = domainWidth - domainEpsilon;
    //}
    //if (p.pos.y() - domainEpsilon < 0.0f) {
    //  p.vel(1) *= dampingFactor;
    //  p.pos.y() = domainEpsilon;
    //}
    //if (p.pos.y() + domainEpsilon > domainHeight) {
    //  p.vel(1) *= dampingFactor;
    //  p.pos.y() = domainHeight - domainEpsilon;
    //}
	if (p.vel.norm() > 1e2)
		printParticle(i);
  }
  simulationTime += dt;
  static auto& t = ParameterManager::instance().get<scalar>("sim.time");
  static auto& vMaxr = ParameterManager::instance().get<scalar>("ptcl.maxVelocity");
  vMaxr = vMax;
  t = simulationTime;
  static auto& dtmin = ParameterManager::instance().get<scalar>("sim.minDt");
  static auto& dtmax = ParameterManager::instance().get<scalar>("sim.maxDt");
  dt = std::clamp(0.4 / vMax, dtmin, dtmax);
  static auto& dtr = ParameterManager::instance().get<scalar>("sim.dt");
  dtr = dt;
}
#include <iomanip>

void computeAlpha(bool density = true) {
#pragma omp parallel for
  for (int32_t i = 0; i < particles.size(); ++i) {
    auto &pi = particles[i];
    auto &di = particlesDFSPH[i];
    vec kernelSum1(0, 0);
    scalar kernelSum2 = 0.0;
    if (density)
      boundaryFunc(pi.pos, [&pi, &kernelSum1, &kernelSum2](auto bpos, auto d, auto k, auto gk, auto triangle) { kernelSum1 += gk; });
    for (int32_t j : pi.neighbors) {
      auto &pj = particles[j];
      auto &dj = particlesDFSPH[j];
      vec kernel = gradW(pi.pos, pj.pos);
      kernelSum1 += dj.area * kernel;
      kernelSum2 += dj.area * dj.area / mass * kernel.dot(kernel);
    }
    di.alpha = -dt * dt * di.area / mass * kernelSum1.dot(kernelSum1) - dt * dt * di.area * kernelSum2;
	if (std::abs(di.alpha) > 1.0) {
		boundaryFunc(pi.pos, [&pi, &kernelSum1, &kernelSum2](auto pb, auto d, auto k, auto gk, auto triangle) { 
			kernelSum1 += gk; 
			if (triangle)
				std::cout << "Triangle:" << std::endl;
			std::cout << std::setprecision(12) << pi.pos.x() << " : " << std::setprecision(12) << pi.pos.y() << " -> " << pb.x() << " : " << pb.y() << " @ " << d << " => " << d << ", " << k << " ==> " << gk.x() << " : " << gk.y() << std::endl;
			});

	}
  }
}
void computeSourceTerm(bool density = true) {
#pragma omp parallel for
  for (int32_t i = 0; i < particles.size(); ++i) {
    auto &pi = particles[i];
    auto &di = particlesDFSPH[i];
    scalar sourceTerm = density ? scalar(1.0) - pi.rho : scalar(0.0);
    if (density)
      boundaryFunc(pi.pos, [&di, &sourceTerm](auto bpos, auto d, auto k, auto gk, auto triangle) {
        sourceTerm = sourceTerm - dt * di.vel.dot(gk);
      });
    for (int32_t j : pi.neighbors) {
      auto &pj = particles[j];
      auto &dj = particlesDFSPH[j];
      sourceTerm -= dt * dj.area * (di.vel - dj.vel).dot(gradW(pi.pos, pj.pos));
    }
    di.source = sourceTerm;
    di.pressure2 = (scalar)0.0;
  }
}
void computeAcceleration(bool density = true) {
#pragma omp parallel for
  for (int32_t i = 0; i < particles.size(); ++i) {
    auto &pi = particles[i];
    auto &di = particlesDFSPH[i];
    vec kernelSum((scalar)0.0, (scalar)0.0);
    for (int32_t j : pi.neighbors) {
      auto &pj = particles[j];
      auto &dj = particlesDFSPH[j];
      kernelSum += -mass * (di.pressure2 / power(pi.rho * rho0, 2) + dj.pressure2 / power(pj.rho * rho0, 2)) *
                   gradW(pi.pos, pj.pos);
    }
    di.accel += kernelSum;
    di.pressure1 = di.pressure2;
  }
}

void updatePressure(bool density = true) {
#pragma omp parallel for
  for (int32_t i = 0; i < particles.size(); ++i) {
    auto &pi = particles[i];
    auto &di = particlesDFSPH[i];
    scalar kernelSum = (scalar)0.0;
    if (density)
      boundaryFunc(pi.pos,
                   [&di, &kernelSum](auto bpos, auto d, auto k, auto gk, auto triangle) { kernelSum += dt * dt * di.accel.dot(gk); });
    for (int32_t j : pi.neighbors) {
      auto &pj = particles[j];
      auto &dj = particlesDFSPH[j];
      kernelSum += dt * dt * dj.area * (di.accel - dj.accel).dot(gradW(pi.pos, pj.pos));
    }
    scalar omega = (scalar)0.5;
    scalar pressure = di.pressure1 + omega / di.alpha * (di.source - kernelSum);
    pressure = density ? std::max(pressure, (scalar)0.0) : pressure;
    scalar residual = kernelSum - di.source;
    if (::abs(di.alpha) < 1e-25 || pressure != pressure || pressure > 1e25)
      pressure = residual = 0.0;
    di.pressure2 = pressure;
    di.dpdt = std::max(residual, (scalar)-0.001) * area;
    di.rhoStar = std::max(residual, (scalar)-0.001) * area;
  }
}

scalar calculateBoundaryPressureMLS(int32_t i, vec pb, bool density = true) {
  vec vecSum(0, 0), d_bar(0, 0);
  matrix M = matrix::Zero();
  scalar sumA = (scalar)0.0, sumB = (scalar)0.0, d_sum = (scalar)0.0;

  auto [ix, iy] = getCellIdx(pb.x(), pb.y());
  for (int32_t xi = -1; xi <= 1; ++xi) {
    for (int32_t yi = -1; yi <= 1; ++yi) {
      const auto &cell = getCell(ix +xi, iy +yi);
      for (auto j : cell) {
        auto &pj = particles[j];
        vec r = pj.pos - pb;
        if (r.squaredNorm() <= support * support) {
          scalar fac = area * W(pj.pos, pb);
          d_bar += pj.pos * fac;
          d_sum += fac;
        }
      }
    }
  }
  d_bar /= d_sum;
  vec x_b = pb - d_bar;

  for (int32_t xi = -1; xi <= 1; ++xi) {
    for (int32_t yi = -1; yi <= 1; ++yi) {
        const auto& cell = getCell(ix + xi, iy + yi);
      for (auto j : cell) {
        auto &pj = particles[j];
        auto &dj = particlesDFSPH[j];
        vec r = pj.pos - pb;
        if (r.squaredNorm() <= (scalar)1.0) {
          scalar Wbbf = W(pj.pos, pb);
          vec pjb = pj.pos - d_bar;
          M += (pjb) * (pjb).transpose();
          vecSum += pjb * dj.pressure2 * area * Wbbf;
          sumA += dj.pressure2 * area * Wbbf;
          sumB += area * Wbbf;
        }
      }
    }
  }
  auto [U, S, V] = svd2x2(M);
  S(0, 0) = abs(S(0, 0)) > (scalar)1e-2f ? (scalar)1.0 / S(0, 0) : (scalar)0.0;
  S(1, 1) = abs(S(1, 1)) > (scalar)1e-2f ? (scalar)1.0 / S(1, 1) : (scalar)0.0;
  S(0, 1) = S(1, 0) = (scalar)0.0;
  matrix Mp = V * S * U.transpose();
  scalar alpha = sumA / sumB;
  auto beta = Mp(0, 0) * vecSum.x() + Mp(0, 1) * vecSum.y();
  auto gamma = Mp(1, 0) * vecSum.x() + Mp(1, 1) * vecSum.y();
  scalar det = M.determinant();
  if (det != det)
    beta = gamma = (scalar)0.0;
  auto pressure = alpha + beta * x_b.x() + gamma * x_b.y();
  if (pressure != pressure || alpha != alpha)
    pressure = (scalar)0.0;
  pressure = density ? std::max(pressure, (scalar)0.0) : pressure;
  //if (pressure > 1e10)
	//  printParticle(i);
  return pressure;
}

void computeBoundaryPressure(bool density = true) {
#pragma omp parallel for
  for (int32_t i = 0; i < particles.size(); ++i) {
    auto &pi = particles[i];
    auto &di = particlesDFSPH[i];
	di.pressureBoundary = 0.0;
    di.accel = vec(0, 0);
    if (!density)
      continue;
    boundaryFunc(pi.pos, [&](auto pb, auto d, auto k, auto gk, auto triangle) {
      scalar pressure = calculateBoundaryPressureMLS(i, pb, density);
      scalar fluidPressure = density ? std::max((scalar)0.0, di.pressure2) : di.pressure2;
      scalar boundaryPressure = density ? std::max((scalar)0.0, pressure) : pressure;
	 // boundaryPressure = fluidPressure;
	  di.pressureBoundary += boundaryPressure;
      di.accel +=
          -scalar(1.0) * rho0 * (fluidPressure / power(pi.rho * rho0, 2) + boundaryPressure / (rho0 * rho0)) * gk;
	  if (boundaryPressure > 1e12 && triangle) {
		  std::cout << pi.pos.x() << " : " << pi.pos.y() << " -> " << pb.x() << " : " << pb.y() << " @ " << d << " => " << d << ", " << k << " ==> " << gk.x() << " : " << gk.y() << std::endl;
		  printParticle(i);
	  }
    });
  }
}

void predictVelocity(bool density = true) {
#pragma omp parallel for
  for (int32_t i = 0; i < particles.size(); ++i) {
    auto &pi = particles[i];
    auto &di = particlesDFSPH[i];
    di.vel = pi.vel + dt * pi.accel;
    di.area = area / pi.rho;
  }
}
void updateVelocity(bool density = true) {
#pragma omp parallel for
  for (int32_t i = 0; i < particles.size(); ++i) {
    auto &pi = particles[i];
    auto &di = particlesDFSPH[i];
    pi.accel += di.accel;
    di.vel += dt * di.accel;
  }
  
}

int32_t divergenceSolve() {
	//return 0;
  predictVelocity();
  computeAlpha(false);
  computeSourceTerm(false);
  //scalar error = (scalar)0.0;
  //int32_t counter = 0;
  scalar totalArea = area * (scalar)particles.size();
  static auto& limit = ParameterManager::instance().get<scalar>("dfsph.divergenceEta");
  static auto& error = ParameterManager::instance().get<scalar>("dfsph.divergenceError");
  static auto& counter = ParameterManager::instance().get<int32_t>("dfsph.divergenceIterations");
  counter = 0;
  do {
    computeBoundaryPressure(false);
    computeAcceleration(false);
    updatePressure(false);
    error = (scalar)0.0;
    for (auto di : particlesDFSPH)
      error += di.dpdt;
    error /= totalArea;
    //std::cout << "Divergence: " << counter << " -> " << error << std::endl;
  } while (counter++ < 2 || (error > (scalar)limit && counter < 256));
  computeBoundaryPressure(false);
  computeAcceleration(false);
  updateVelocity(false);
  return counter;
}
int32_t densitySolve() {
  predictVelocity();
  computeAlpha(true);
  computeSourceTerm(true);
  //scalar error = (scalar)0.0;
  //int32_t counter = 0;
  scalar totalArea = area * (scalar)particles.size();
  static auto& limit = ParameterManager::instance().get<scalar>("dfsph.densityEta");
  static auto& error = ParameterManager::instance().get<scalar>("dfsph.densityError");
  static auto& counter = ParameterManager::instance().get<int32_t>("dfsph.densityIterations");
  counter = 0;
  do {
    computeBoundaryPressure(true);
    computeAcceleration(true);
    updatePressure(true);
    error = (scalar)0.0;
    for (auto di : particlesDFSPH)
      error += di.rhoStar;
    error /= totalArea;
   // std::cout << "Density: " << counter << " -> " << error << std::endl;
  } while (counter++ < 3 || (error > (scalar)limit && counter < 256));
  computeBoundaryPressure(true);
  computeAcceleration(true);
  updateVelocity();
  return counter;
}

void resetFrame() {
    
  for (auto &v : cellArray)
    v.clear();
  for (auto &p : particles)
    p.reset();
  if (particlesDFSPH.size() != particles.size())
    particlesDFSPH.resize(particles.size());
  for (auto &d : particlesDFSPH)
    d.reset();
  static auto& numPtcls = ParameterManager::instance().get<std::size_t>("props.numptcls");
  numPtcls = particles.size();
} 

void initializeSPH(int32_t scene) {
    ParameterManager::instance().newParameter("ray.origin", vec(50,25), { .constant = false});
    ParameterManager::instance().newParameter("ray.target", vec(5,5), { .constant = false });
    ParameterManager::instance().newParameter("ray.fov", 10.0, { .constant = false , .range = Range{0.1,360.0} });
    ParameterManager::instance().newParameter("ray.resolution", 8, { .constant = false , .range = Range{16,4096} });
    ParameterManager::instance().newParameter("ray.render", true, { .constant = false });
    ParameterManager::instance().newParameter("ray.renderImplicit", true, { .constant = false });
    ParameterManager::instance().newParameter("ray.renderExplicit", false, { .constant = false });
    ParameterManager::instance().newParameter("ray.hScale", 1.0, { .constant = false });
    ParameterManager::instance().newParameter("ray.subSteps", 32, { .constant = false, .range = Range{2,64} });
    ParameterManager::instance().newParameter("ray.gScaleFine", 32.0, { .constant = false, .range = Range{0.01,2.0} });
    ParameterManager::instance().newParameter("ray.gScaleExplicit", 1.0, { .constant = false, .range = Range{0.01,2.0} });
    ParameterManager::instance().newParameter("ray.gScaleImplicit", 1.0, { .constant = false, .range = Range{0.01,2.0} });
    ParameterManager::instance().newParameter("ray.iso", -scalar(0.5), { .constant = false, .range = Range{-1.0, 1.0} });

    ParameterManager::instance().newParameter("sim.frame", 0, { .constant = false });
    ParameterManager::instance().newParameter("field.render", false, { .constant = false });
    ParameterManager::instance().newParameter("field.min", 0.0, { .constant = false , .range = Range{-10.0,10.0} });
    ParameterManager::instance().newParameter("field.max", 1.0, { .constant = false, .range = Range{-10.0,10.0} });
    ParameterManager::instance().newParameter("marching.render", true, { .constant = false });
    ParameterManager::instance().newParameter("marching.solid", false, { .constant = false });
    ParameterManager::instance().newParameter("marching.iso", -scalar(0.5), { .constant = false, .range = Range{-1.0, 1.0} });
    ParameterManager::instance().newParameter("marching.gScale", scalar(1), { .constant = false, .range = Range{0.01,2.0} });
    ParameterManager::instance().newParameter("marching.hScale", scalar(1), { .constant = false, .range = Range{0.01,2.0} });
    ParameterManager::instance().newParameter("marching.method", int32_t(0), { .constant = false, .range = Range{0,0} });
    ParameterManager::instance().newParameter("render.showGrid", false, { .constant = false });

    ParameterManager::instance().newParameter("colorMap.min", scalar(0), { .constant = false , .range = Range{-10.0,10.0} });
    ParameterManager::instance().newParameter("colorMap.map", 0, { .constant = false , .range = Range{0,2} });
    ParameterManager::instance().newParameter("colorMap.auto", true, { .constant = false});
    ParameterManager::instance().newParameter("colorMap.max", scalar(25), { .constant = false , .range = Range{-10.0,10.0} });

    ParameterManager::instance().newParameter("sim.time", simulationTime, { .constant = true });
    ParameterManager::instance().newParameter("props.numptcls", particles.size(), { .constant = true });
    ParameterManager::instance().newParameter("props.scale", scale, { .constant = true });
    ParameterManager::instance().newParameter("ptcl.render", true, { .constant = false });
    ParameterManager::instance().newParameter("ptcl.radius", radius, { .constant = true });
    ParameterManager::instance().newParameter("sim.minDt", minDt, { .constant = false, .range = Range{0.001, 0.016} });
    ParameterManager::instance().newParameter("sim.maxDt", maxDt, { .constant = false, .range = Range{0.001, 0.016} });
    ParameterManager::instance().newParameter("sim.dt", dt, { .constant = true });
    ParameterManager::instance().newParameter("props.domainWidth", domainWidth, { .constant = true });
    ParameterManager::instance().newParameter("props.domainHeight", domainHeight, { .constant = true });
    ParameterManager::instance().newParameter("props.cellsX", cellsX, { .constant = true });
    ParameterManager::instance().newParameter("props.cellsY", cellsY, { .constant = true });
    ParameterManager::instance().newParameter("props.packing_2D", packing_2D, { .constant = true });
    ParameterManager::instance().newParameter("props.support", support, { .constant = true });
    ParameterManager::instance().newParameter("ptcl.area", area, { .constant = true });
    ParameterManager::instance().newParameter("ptcl.mass", mass, { .constant = true });
    ParameterManager::instance().newParameter("ptcl.maxVelocity", scalar(0), { .constant = true });
    ParameterManager::instance().newParameter("ptcl.viscosityConstant", viscosityConstant, { .constant = false, .range = Range{0.01, 0.05} });

    ParameterManager::instance().newParameter("dfsph.densityEta", scalar(0.001), { .constant = true });
    ParameterManager::instance().newParameter("dfsph.divergenceEta", scalar(0.001), { .constant = true });
    ParameterManager::instance().newParameter("dfsph.densityIterations", 0, { .constant = true });
    ParameterManager::instance().newParameter("dfsph.divergenceIterations", 0, { .constant = true });
    ParameterManager::instance().newParameter("dfsph.densityError", scalar(0), { .constant = true });
    ParameterManager::instance().newParameter("dfsph.divergenceError", scalar(0), { .constant = true });


	triangles.clear();
//	std::cout << boundaryKernel(-1.0) << " : " << boundaryKernel(0.0) << " : " << boundaryKernel(1.0) << std::endl;
  // particles = genParticles(vec(domainEpsilon+0.5, domainEpsilon+0.5), vec(domainWidth / 8, domainHeight -
  // domainEpsilon * 2.0));
  //auto particles1 = genParticles(vec(27.5, 7.5), vec(47.5, 27.5));
    auto particles1 = genParticles(vec(15, 35), vec(15.1, 35.1));
   //auto particles1 = genParticles(vec(20, 20), vec(30, 30));
    //auto particles2 = genParticles(vec(10.25, 10.25), vec(20.25, 20.25));
    //auto particles2 = genParticles(vec(10.25, 10.25), vec(10.5, 10.5));
    auto particles2 = genParticles(vec(5 + offset, 5 + offset), vec(20 + offset, 25 + offset));
    auto particles4 = genParticles(vec(45.25, 25.25), vec(55.25, 35.25));
    auto particles3 = genParticles(vec(5.25, 25.25), vec(20, 40));
    if (simulationCase != cornerAngle::Box1 && simulationCase != cornerAngle::Box1_4 && simulationCase != cornerAngle::Box4) {
        for (auto& p : particles3)
            particles.push_back(p);
    }
    else {
        for (auto& p : particles2) {
            //p.vel = vec(5, 0);
            particles.push_back(p);
        }
        for (auto& p : particles4) {
            p.vel = vec(-5, 0);
           // particles.push_back(p);
        }

    }
    //triangles.push_back(Triangle{ {5,5},{95,5},{95,0} });
    //triangles.push_back(Triangle{ {5,5},{95,0},{5,0} });
    //triangles.push_back(Triangle{ {0,0},{0,50},{5,50} });
    //triangles.push_back(Triangle{ {0,0},{5,50},{5,0} });
    float d = 1.;
  switch (simulationCase) {
  case cornerAngle::acute:
    triangles.push_back(Triangle{{50, 45}, {50, 25}, {25, 45}}); // 135
  case cornerAngle::ortho:
    triangles.push_back(Triangle{{50, 25}, {50, 45}, {75, 45}});   // 90
  case cornerAngle::obtuse:
    triangles.push_back(Triangle{{50, 25}, {95, 25}, {95, 61}});  // 45
    triangles.push_back(Triangle{{50, 25}, {75, 25}, {75, 5}}); // 0
  case cornerAngle::nobtuse:
    triangles.push_back(Triangle{{50, 25}, {75, 5}, {50, 5}}); // -45
  case cornerAngle::northo:
    triangles.push_back(Triangle{{50, 25}, {50, 5}, {25, 5}}); // -90
  case cornerAngle::nacute:
    triangles.push_back(Triangle{{50, 25}, {5, -11}, {5, 25}}); // -135
    break;
  case cornerAngle::Box1:
      d = 0.02559;
      break;
  case cornerAngle::Box4:
      d = 4.;
      break;
  case cornerAngle::Box1_4:
      d = 0.25;
      break;
  default: break;
  }
  if (simulationCase == cornerAngle::Box1 || cornerAngle::Box4 == simulationCase || cornerAngle::Box1_4 == simulationCase) {
	  triangles.push_back(Triangle{ {50,5},{50,5.0 + d},{50.0 + d,5.0 + d} });
      triangles.push_back(Triangle{ {50,5},{50.0 + d,5.0 + d},{50.0 + d,5} });

  }


  if (simulationCase != cornerAngle::Box1 && simulationCase != cornerAngle::Box1_4 && simulationCase != cornerAngle::Box4) {
      vec P1(5, 25);
      vec P2(50, 25);
      vec P3(0, 0);
      if (simulationCase == cornerAngle::acute)
          P3 = vec(0, 75);
      if (simulationCase == cornerAngle::ortho)
          P3 = vec(50, 75);
      if (simulationCase == cornerAngle::obtuse)
          P3 = vec(100, 75);
      if (simulationCase == cornerAngle::nobtuse)
          P3 = vec(100, -75);
      if (simulationCase == cornerAngle::northo)
          P3 = vec(50, -75);
      if (simulationCase == cornerAngle::nacute)
          P3 = vec(0, -75);

      std::vector<vec> polygon;
      polygon.push_back(P1);
      polygon.push_back(P2);
      if (simulationCase == cornerAngle::acute) {
          polygon.push_back(vec(25, 45));
          polygon.push_back(vec(5, 45));
      }
      if (simulationCase == cornerAngle::ortho) {
          polygon.push_back(vec(50, 45));
          polygon.push_back(vec(5, 45));
      }
      if (simulationCase == cornerAngle::obtuse) {
          polygon.push_back(vec(75, 45));
          polygon.push_back(vec(5, 45));
      }
      if (simulationCase == cornerAngle::nobtuse) {
          polygon.push_back(vec(75, 5));
          polygon.push_back(vec(95, 5));
          polygon.push_back(vec(95, 45));
          polygon.push_back(vec(5, 45));
      }
      if (simulationCase == cornerAngle::northo) {
          polygon.push_back(vec(50, 5));
          polygon.push_back(vec(95, 5));
          polygon.push_back(vec(95, 45));
          polygon.push_back(vec(5, 45));
      }
      if (simulationCase == cornerAngle::nacute) {
          polygon.push_back(vec(25, 5));
          polygon.push_back(vec(95, 5));
          polygon.push_back(vec(95, 45));
          polygon.push_back(vec(5, 45));
      }
  }
  else {
      vec P1(5, 5);
      vec P2(95, 5);
      vec P3(95, 45);
      vec P4(5, 45);

      polygon.push_back(P2);
      polygon.push_back(P3);
      polygon.push_back(P4);
      polygon.push_back(P1);
      float d = 0.0559f;
      if (simulationCase == cornerAngle::Box4)
          d = 4.f;
      if (simulationCase == cornerAngle::Box1_4)
          d = 0.25f;
      if (simulationMethod == boundaryMethod::sdf) {
          polygon.push_back(vec{ 50,5 });
          polygon.push_back(vec{ 50,5 + d });
          polygon.push_back(vec{ 50 + d,5 + d });
          polygon.push_back(vec{ 50 + d,5 });
      }
  }

  

}
#include <tools/timer.h>
void timestep() {
    TIME_CODE(0, "Simulation - Overall",
        TIME_CODE(1, "Simulation - Reset", resetFrame());
        TIME_CODE(2, "Simulation - Cell construction", fillCells());
        TIME_CODE(3, "Simulation - Neighbor search", neighborList());
        TIME_CODE(4, "Simulation - Density", density());
        TIME_CODE(5, "Simulation - External", externalForces());
        TIME_CODE(6, "Simulation - Divergence", divergenceSolve());
        TIME_CODE(7, "Simulation - Density", densitySolve());
        TIME_CODE(8, "Simulation - XSPH", XSPH());
        TIME_CODE(9, "Simulation - Integration", Integrate());
    );
    ParameterManager::instance().get<int32_t>("sim.frame")++;
  //auto cellBegin = clk::now();
  //fillCells();
  //auto neighBegin = clk::now();
  //neighborList();
  //auto densityBegin = clk::now();
  //density();
  //auto externalBegin = clk::now();
  //externalForces();
  //auto divSolveBegin = clk::now();
  //int32_t div_it = divergenceSolve();
  //auto incSolveBegin = clk::now();
  //int32_t den_it = densitySolve();
  //auto xsphBegin = clk::now();
  //XSPH();
  //auto integrateBegin = clk::now();
  //Integrate();
  //auto endFrame = clk::now();
  //std::stringstream sstream;
  //sstream << "########################################################################################################\n";
  ////sstream << "Frame took " << toMs(endFrame - beginFrame) << "ms particle count " << particles.size() << "\n";
  //sstream << "Cells      " << toMs(neighBegin - cellBegin) << "ms Neighbors      " << toMs(densityBegin - neighBegin) << "\n";
  //sstream << "Density    " << toMs(externalBegin - densityBegin) << "ms External       " << toMs(divSolveBegin - externalBegin) << "\n";
  //sstream << "Divergence " << toMs(incSolveBegin - divSolveBegin) << "ms Incompressible " << toMs(xsphBegin - incSolveBegin) << "\n";
  //sstream << "XSPH       " << toMs(integrateBegin - xsphBegin) << "ms Integrate      " << toMs(endFrame - integrateBegin) << "\n";
  //sstream << "Divergence Iterations " << div_it << ", Incompressibility Iterations " << den_it << "\n";
  //std::cout << sstream.str();
}

using clk = std::chrono::high_resolution_clock;
scalar toMs(clk::duration dur) {
  return static_cast<scalar>(std::chrono::duration_cast<std::chrono::microseconds>(dur).count()) / scalar(1000.0);
}

std::vector<Particle> genParticles(vec minCoord, vec maxCoord) {
  auto gen_position = [](auto r, auto i, auto j) -> vec {
    return vec(r * (2.0 * scalar(i) + scalar(j % 2)), r * ::sqrt(3.0) * scalar(j));
  };
  auto diff = maxCoord - minCoord;
  auto requiredSlices_x = ::ceil(diff.x() / packing_2D);
  auto requiredSlices_y = ::ceil(diff.y() / (::sqrt(2.0) * packing_2D));
  std::vector<Particle> points;
  for (int32_t x_it = 0; x_it < requiredSlices_x + 1; ++x_it)
    for (int32_t y_it = 0; y_it < requiredSlices_y + 1; ++y_it) {
      vec p = minCoord;
      vec g = gen_position(packing_2D, x_it, y_it);
      vec pos = p + g;
      if (pos.x() < maxCoord.x() && pos.y() < maxCoord.y())
        points.emplace_back(pos.x(), pos.y());
    }
  return points;
}

void printParticle(int32_t idx) {
  auto &p = particles[idx];
  auto &d = particlesDFSPH[idx];
  std::cout << "###############################################\n";
  std::cout << "Particle: " << idx << "\n";
  std::cout << "rho: " << p.rho << "\n";
  std::cout << "pos: [" << p.pos.x() << " : " << p.pos.y() << "], vel: [" << p.vel.x() << " : " << p.vel.y()
            << "], acc: [" << p.accel.x() << " : " << p.accel.y() << "]\n";
  std::cout << "alpha: " << d.alpha << ", area: " << d.area << ", source: " << d.source << ", boundaryP: " << d.pressureBoundary <<"\n";
  std::cout << "pressure1: " << d.pressure1 << ", pressure2: " << d.pressure2 << ", dpdt: " << d.dpdt
            << ", rho*: " << d.rhoStar << "\n";
  std::cout << "predictedVel: [" << d.vel.x() << " : " << d.vel.y() << "], pressureAccel: [" << d.accel.x() << " : "
            << d.accel.y() << "]" << std::endl;
}
