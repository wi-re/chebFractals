#include <tools/exceptionHandling.h>
#include "gui/glui.h"
#include <sstream>
#include <thread>
#include <windows.h>
#include <iostream> 

BOOL CtrlHandler(DWORD fdwCtrlType) {
    std::clog << "Caught signal " << fdwCtrlType << std::endl;
    switch (fdwCtrlType)
    {
    case CTRL_CLOSE_EVENT:
        GUI::instance().quit();
        GUI::instance().render_lock.unlock();
        std::this_thread::sleep_for(std::chrono::milliseconds(2000));
        return(TRUE);

    default:
        return FALSE;
    }
}
#include <test.h>
#include <cheb/cheb.h>
int main(int argc, char* argv[]) 
try 
{
    //cheb::Function testFn([](cheb::scalar s) {
    //    if (s < 0) return -1.;
    //    return 1.;
    //    });
    //testInterval();
    //testDomain();
    //testChebTech();
    //testChebTech_functions();
    //testArithmetic();
    //testRoots();
    //testUtilities();

    //testFunction_Construction();
    //testFunction_Properties();
    //testFunction_ClassUsage();
    //testFunction_Evaluation();
    //testFunction_Calculus();
    //testFunction_Roots();
    //testFunction_Arithmetic();
    //testFunction();
    if (!SetConsoleCtrlHandler((PHANDLER_ROUTINE)CtrlHandler, TRUE)) {
        std::cerr << "Could not set CtrlHandler. Exiting." << std::endl;
        return 0;
    }
    //_set_se_translator(translator);

    auto& gui = GUI::instance();
    gui.render_lock.lock();
    gui.initParameters(argc, argv);
    gui.initGVDB();
    gui.initSimulation();
    gui.initGL();
    gui.renderLoop();
    return 0;
}
CATCH_DEFAULT